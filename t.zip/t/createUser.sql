CREATE DATABASE prac013;

USE prac013;
CREATE TABLE testCountry (
    id VARCHAR(255),
    name VARCHAR(255) NOT NULL
);


LOAD DATA INFILE '/var/lib/mysql-files/country.csv' 
INTO TABLE testCountry 
FIELDS TERMINATED BY ',' 
LINES TERMINATED BY '\n';
