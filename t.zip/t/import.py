import csv
import json
import pandas as pd
import sys, getopt, pprint
from pymongo import MongoClient
#CSV to JSON Conversion
csvfile = open('/home/manick/practicals/mdbms/mysql/data/country.csv', 'r')
reader = csv.DictReader( csvfile )
mongo_client=MongoClient() 
db=mongo_client.october_mug_talk
db.segment.drop()
header= [ "Rank", "Name"]
print len(reader)
	# for each in reader:
	# 	row={}
	# 	for field in header:
	# 		row[field]=each[field]
	# 	db.segment.insert(row)