from pymongo import MongoClient
connection = MongoClient()
db = connection.students.ctec121
student_record = {}
flag = True
while (flag):
   student_name = input("Enter student name: ")
   student_grade = input("Enter studentgrade: ")
   student_record = {'name':student_name,'grade':student_grade}
   db.insert(student_record)
   flag = input('Enter another record? ')
   if (flag[0].upper() == 'N'):
      flag = False
results = db.find()
for record in results:
   print(record['name'] + ',',record['grade'])
connection.close()