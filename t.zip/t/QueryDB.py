import mysql.connector
from mysql.connector import Error
 
 
def connect():
    """ Connect to MySQL database """
    try:
        conn = mysql.connector.connect(host='localhost',
                                       database='prac11',
                                       user='root',
                                       password='root')
        if conn.is_connected():
            print('Connected to MySQL database')
 
    except Error as e:
        print(e)
 
    finally:
        conn.close()

def getRowCount():
    try:
        conn = mysql.connector.connect(host=hostname,
                                       database=dbname,
                                       user='root',
                                       password='root')
        cursor = conn.cursor()
        cursor.execute(query)
 
        row = cursor.fetchall()
        rowcount = cursor.rowcount
        return rowcount

        while row is not None:
            # print(row)
            row = cursor.fetchall()

 
    except Error as e:
        print(e)
 
    finally:
        cursor.close()
        conn.close()
    return row
 
if __name__ == '__main__':
    connect()
    count = getRowCount('localhost','prac11',"SELECT * FROM testCountry")
    print(count)
